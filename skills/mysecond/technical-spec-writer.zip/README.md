# Technical Spec Writer

Write technical specifications with architecture, data models, and API designs.

---

## Installation (30 seconds)

**In Claude Code Desktop:**
1. Unzip this file
2. Move the `technical-spec-writer` folder to `~/.claude/skills/` (works across all projects)
3. Restart Claude Code Desktop

**Advanced:** For project-specific use, place in `.claude/skills/` within your project folder instead.

**In Claude Code Terminal:**
1. Unzip this file
2. Move the `technical-spec-writer` folder to `~/.claude/skills/`
3. Restart Claude Code

**In Claude.ai (Chat/Desktop):**
1. Download this ZIP file (don't unzip)
2. Go to **Settings → Capabilities → Skills**
3. Click **+ Add** → **Upload a skill**
4. Select the ZIP file

---

## How to Use

In any chat, type:
```
/tech-spec
```

Claude will walk you through the skill step-by-step.

**💡 Pro tip:** This skill works great standalone, but it's even more powerful with full context. Get personalized outputs that know your company, product, and personas with the [PM Operating System](https://mysecond.ai/pricing) ($499).

---

## What You'll Get

- Architecture diagram and components
- Database schema with SQL
- API endpoints with request/response examples
- Permission matrix
- Edge case documentation

---

## Learn More

→ [Full documentation](https://mysecond.ai/skills/technical-spec-writer)
→ [Browse all skills](https://mysecond.ai/skills)
→ [Browse agent workflows](https://mysecond.ai/workflows) to run 10+ tasks in parallel — analyze 20 interviews, research 5 competitors, all at once
→ [Get the PM Operating System](https://mysecond.ai/pricing) for personalized context + all skills + workflows

---

Built with ❤️ by mySecond — Your PM Operating System
